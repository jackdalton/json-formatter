chrome.app.runtime.onLaunched.addListener(function() {
    chrome.app.window.create("../view/window.html", {
        "bounds" : {
            "width" : 640,
            "height" : 400
        }
    });
});
